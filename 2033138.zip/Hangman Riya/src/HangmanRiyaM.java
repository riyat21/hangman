import java.util.*;
import java.io.*;

public class HangmanRiyaM { //declaring class name 
	/*
     * In main we run the method startGame, as we need this in order to be able to rerun the game
     * */
   public static void main(String[] args) throws IOException { 

       startGame("");
   }
   /*
    * startGame is the method where we will passing on variables, and running multiple methods
    * We set most strings, ints, booleans here
    * We use the ArrayList function in order to create Arraylists, as this makes it easier
    * We also generate a random word from the array here
    * We also remove the last word from the array if needed
    * */
   public static void startGame(String lastWord) throws IOException {
       int GuessesRemaining = 6; //declaring int variable which is number of guesses remaining 
       int Errors = 0; //declaring int errors which is set to 0 at the start of the game
       int Max_Errors = 3; //declaring max numbers of error made before a guess is deducted 
       boolean CorrectG = false; //If guess correct is set to default false 
       boolean GameFin = true; //If game is finished, its set to default true
       String Name = " "; //Empty string called name as player can input their name here
       String notUsed = "abcdefghijklmnopqrstuvwxyz"; //String which lists the alphabet for the user to choose a letter from 


       ArrayList<String> WordList = new ArrayList<String>(  //An array called wordlist 
               Arrays.asList("video", "work", "car", "family", "travel", "world")); //generation of  a random word from the array list 


       if (!lastWord.equals("")) { 
           WordList.remove(lastWord);
       }
       int randomNumber = (int) (Math.random() * WordList.size());
       String Word = WordList.get(randomNumber);

       Name = Introduction(Name);
       RandomWord(Word);
       Game(GuessesRemaining, notUsed, WordList, Word, GameFin, CorrectG, Errors, Max_Errors, Name); // Method

   }
   /*
    * Method to get the name
    * */
   public static String Introduction(String Name) {
       Name = inputString("Please, Enter Your Name : ");

       print("Welcome To Hangman " + Name
               + " You Have 6 Guesses And For Every 3 Errors, A Guess Will Be Deducted From The Remaining Guesses");
       print("An Error Occurs If You Input A Letter Which Has Been Entered Earlier Or If Your Input Is Not A Letter");
       return Name;
   }
   /*
    * Print out the length of the word by using the .length function
    * */
   public static String RandomWord(String Word) {
       print("The Word Has A Length Of " + Word.length() + " Letters");
       return Word;
   }
   /*
    * This is where we run the main game
    * We include a error check here which checks,if its letter, or if its been repeated or not, or if its one length
    * We also update a Letters Array
    * We also ask the user if they want to play again
    * We also update the string letters used here
    * As well as update booleans
    * */
   public static void Game(int GuessesRemaining, String notUsed, ArrayList<String> WordList, String Word,
                           boolean GameFin, boolean CorrectG, int Errors, int Max_Errors, String name)
           throws IOException {
       char[] letters = new char[Word.length()];
       int Score = 0;
       for (int i = 0; i < letters.length; i++) {
           letters[i] = '.';
       }

       while (GuessesRemaining > 0) {
           print("Guesses Remaining: " + GuessesRemaining);
           print("Error Count: " + Errors);
           String input = " ";
           input = inputString("Input: ");

           while (input.length() != 1 || !Character.isLetter(input.charAt(0)) || new String(letters).contains(input)) {
               print("Error Input - Try Again");
               Errors = Errors + 1;
               print("Remaining Guesses: " + GuessesRemaining);
               System.out.println("Error Count: " + Errors);
               if (Errors == Max_Errors) {
                   print("You Have Entered A Error 3 Times, 1 Guess Will Be Deducted, Error Count Will Restart");
                   GuessesRemaining--;
                   Errors = 0;
                   print("Remaining Guesses : " + GuessesRemaining);
                   System.out.println("Error Count: " + Errors);

               }
               input = inputString("Input : ");
           }

           char letter = input.charAt(0);

           CorrectG = false;

           for (int i = 0; i < Word.length(); i++) {
               char l = Word.charAt(i);

               if (l == letter) {
                   letters[i] = l;
                   CorrectG = true;
                   print("This Letter Is The Correct Guess");

               }
           }

           if (!CorrectG) {
               GuessesRemaining = GuessesRemaining - 1;
           }

           GameFin = true;
           System.out.print("Word: ");


           for (int i = 0; i < letters.length; i++) {
               if (letters[i] == '.') {
                   GameFin = false;
               }

               System.out.print(letters[i]);
           }

           System.out.println();
           notUsed = notUsed.replace(letter, '*');
           System.out.println("Letters Not used: " + notUsed);

           System.out.println("--------------------------");

           if (GameFin) {
               Score = GuessesRemaining * Word.length();
               System.out.println("You Have Won!");
               System.out.println("Your Score Is: " + Score);
               break;
           }
       }

       if (GuessesRemaining == 0) {
           System.out.println("You Have Lost!");
           System.out.println("The Word Is: " + Word);
           System.out.println("Score = 0 ");
       }

       saveScore(name, Score);
       readScore();

       System.out.println("Would you like to play again?");

       String answer = inputString("Type Y for Yes or N for No");
       if (answer.equals("Y")) {
           startGame(Word);
       } else {
           print("Exiting Program");
           System.exit(0);
       }
   }
   /*
    * This method was created so instead of creating new scanners, you can simply
    * create a input request using a string variable
    * */
   public static String inputString(String message) {
       Scanner scanner = new Scanner(System.in);
       String answer;
       System.out.println(message);
       answer = scanner.nextLine();
       return answer;
   }
   /*
    * This method was created so print can be used instead of system.out.println
    * */
   public static void print(String message) {
       System.out.println(message);
   }
   /*
    * saveScore is the method that will be saving the score
    * We first of all create a new csv file called leaderboard, if it does not exist
    * We are assigning it to save name, score
    * We create a if statement, where one saves data if the leaderboard exists
    * Other creates a new file and then saves the score, if it does not exist
    * */
   public static void saveScore(String name, int score) throws IOException {

       File csvFile = new File("./leaderboard.csv");
       if (csvFile.isFile()) {
           FileWriter csvWriter = new FileWriter("./leaderboard.csv", true);
           csvWriter.append(name);
           csvWriter.append(",");
           csvWriter.append(String.valueOf(score));
           csvWriter.append("\r\n");
           csvWriter.flush();
           csvWriter.close();
           System.out.println("Score saved.");

       } else {
           System.out.println("Creating leaderboard.");
           FileWriter csvWriter = new FileWriter("./leaderboard.csv", true);
           csvWriter.append("Name");
           csvWriter.append(",");
           csvWriter.append("Score");
           csvWriter.append("\r\n");
           csvWriter.append(name);
           csvWriter.append(",");
           csvWriter.append(String.valueOf(score));
           csvWriter.append("\r\n");
           csvWriter.flush();
           csvWriter.close();
           System.out.println("Score saved.");
       }
   }
   /* In readScore() we are reading the csv file in order to store the data
    * We are reading the name and score of all the data
    * Sorting it using the collections io
    * Then Printing it
    * We are also displaying the high score by reading the highest set of data after its been sorted
    * */
   public static void readScore() throws FileNotFoundException, IOException {
       System.out.println("=========LEADERBOARD=========");
       String Text = " ";
       System.out.println("Highest Score: " + Text);
       File csvFile = new File("./leaderboard.csv");
       String row;
       ArrayList<Player> leaderboard = new ArrayList<>();
       if (csvFile.isFile()) {

           BufferedReader csvReader = new BufferedReader(new FileReader("./leaderboard.csv"));
           Text = csvReader.readLine();
           int line = 0;
           while ((row = csvReader.readLine()) != null) {
               String[] player = row.split(",");
               if (line != 0) {
                   leaderboard.add(new Player(player[0], Integer.parseInt(player[1])));
                   

               }
               line++;
           }
           csvReader.close();
           leaderboard.sort(Collections.reverseOrder());
           for (Player player : leaderboard) {
               System.out.println(player.toString());

           }
       } else {
           System.out.println("Leaderboard can't be displayed.");
       }

   }
}
/*
* Creating a class for player so we able to create a leaderboard
* We also use setters and getters in order to get the name and score
* */
class Player implements Comparable<Player> {
   private String name;
   private int score;

 //Creating a constructor for player
   public Player(String name, int score) {
       this.name = name;
       this.score = score;
   }

   public String getName() {
       return this.name;
   }

   public int getScore() {
       return this.score;
   }

// Overridden functions since we are working with array of objects
   @Override
   public String toString() {
       return this.name + "     " + this.score;
   }

// CompareTo method overridden for sorting array of objects
   @Override
   public int compareTo(Player o) {
       if (this.score != o.getScore()) {
           return this.score - o.getScore();
       }
       return this.name.compareTo(o.getName());
   }
}

